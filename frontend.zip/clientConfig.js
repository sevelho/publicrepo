var clientConfig = {
    clientId: "c87148a3-d33a-4420-8221-e2ae840e6ec4",
    authority: "https://login.microsoftonline.com/72f988bf-86f1-41af-91ab-2d7cd011db47",
    websocketsEndpoint: 'https://azurexplorer-backend.azurewebsites.net/rootChannel',
    //websocketsEndpoint: 'https://localhost:44303/rootChannel',
};