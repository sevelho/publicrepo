self.__precacheManifest = [
  {
    "revision": "a22a872ca1aa15d19393",
    "url": "/static/css/main.8f0b0e80.chunk.css"
  },
  {
    "revision": "a22a872ca1aa15d19393",
    "url": "/static/js/main.7d9e5b0a.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "0925f4ad83952e7c4194",
    "url": "/static/js/2.9a490bef.chunk.js"
  },
  {
    "revision": "20910fe3e95a24e639b9d482d84bfd58",
    "url": "/index.html"
  }
];